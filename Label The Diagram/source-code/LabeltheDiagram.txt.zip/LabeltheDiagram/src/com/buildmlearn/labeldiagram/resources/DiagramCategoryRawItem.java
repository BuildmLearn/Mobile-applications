package com.buildmlearn.labeldiagram.resources;

public class DiagramCategoryRawItem {

}
