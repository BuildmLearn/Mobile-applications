"Orial"  
(c) 2009 by Salman Boosty

---------------------------------
---------------------------------
Font family: Orial
Font subfamily: Bold
Full font name: Orial_ Bold
Version 1.00 November 10, 2009
Postscript font name:Orial_Bold
---------------------------------
---------------------------------

Actually, The personal and non-commercial use of my font is free.
But Donations are accepted and highly appreciated!
The use of my fonts for commercial and profit purposes is prohibited, unless a small donation is send to me and send the example.
Paypal: sboosty@yahoo.com

These font files may not be modified or renamed.
This readme file must be included with each font.
Redistribute? Sure, but send me an information e-mail.

If you like the font, please e-mail: 
sboosty@yahoo.com


Proprietry Rights: 
All contents of the Orial typeface are � Copyright Salman Boosty 2009. All rights reserved. All rights not expressly granted here are reserved.
