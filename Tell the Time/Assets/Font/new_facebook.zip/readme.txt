New Facebook is licensed under a Creative Commons Attribution 3.0
Unported License. http://creativecommons.org/licenses/by/3.0/


prask.svk@gmail.com